<?php
/**
 * This is a not a file-level DocBlock, because it precedes a class declaration
 * 
 * A warning will be raised, saying that no file-level DocBlock is present
 * and this DocBlock will attach to the class statement
 * @package SomePackage
 */
class foo {}
