<?php
/**
 * This is a file-level DocBlock
 */
/**
 * This is a normal class-level DocBlock
 * 
 * this DocBlock will attach to the class statement
 * @package SomePackage
 */
class foo {}
