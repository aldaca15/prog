<?php
/**
 * This is a not a file-level DocBlock
 * 
 * This DocBlock will attach to the define statement
 */
define('foo', 'bar');
