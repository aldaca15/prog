<?php
/**
 * This is documentation for the function
 */
// a comment!
function roar() { echo 'ROAR'; }
