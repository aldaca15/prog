<?php
/**
 * This is a file-level DocBlock
 * 
 * A warning will be raised, saying that to document the define, use
 * another DocBlock XXX todo?
 * @package SomePackage
 */
define('foo', 'bar');
