<?php
/**
 * This is a file-level DocBlock
 * 
 * No warning will be raised.  This is the recommended usage
 * @package SomePackage
 */
/**
 * This is a not a file-level DocBlock, because it precedes a class declaration
 * 
 * This is also the recommended usage
 * @package SomePackage
 */
class foo {}
