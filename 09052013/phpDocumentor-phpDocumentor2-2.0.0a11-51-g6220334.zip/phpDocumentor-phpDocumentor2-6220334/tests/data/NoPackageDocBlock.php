<?php
/**
 * File has no @package tag but contains a @subpackage tag
 *
 * @subpackage Validator
 * @copyright  Copyright (c) 2010-2011 Mike van Riel / Naenius. (http://www.naenius.com)
 * @author     Ben Selby <benmatselby@gmail.com>
 * @author     Mike van Riel <mike.vanriel@naenius.com>
 */

/**
 * This class has no @package tag but contains a @subpackage tag
 *
 * @subpackage Validator
 * @copyright  Copyright (c) 2010-2011 Mike van Riel / Naenius. (http://www.naenius.com)
 * @author     Ben Selby <benmatselby@gmail.com>
 * @author     Mike van Riel <mike.vanriel@naenius.com>
 */
class NoPackageDocBlock
{

}