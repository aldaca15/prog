<?php

function noFunctionDocBlock()
{

}