Inline tag reference
====================

.. toctree::
   :maxdepth: 1

   inline-tags/example
   inline-tags/internal
   inline-tags/inheritdoc
   inline-tags/link