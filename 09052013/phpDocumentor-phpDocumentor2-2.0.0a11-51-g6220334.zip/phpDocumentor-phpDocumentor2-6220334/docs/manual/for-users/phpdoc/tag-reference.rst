Tag reference
=============

.. toctree::
   :maxdepth: 1

   tags/api
   tags/author
   tags/category
   tags/copyright
   tags/deprecated
   tags/example
   tags/filesource
   tags/global
   tags/ignore
   tags/internal
   tags/license
   tags/link
   tags/method
   tags/package
   tags/param
   tags/property
   tags/property-read
   tags/property-write
   tags/return
   tags/see
   tags/since
   tags/source
   tags/subpackage
   tags/throws
   tags/todo
   tags/uses
   tags/var
   tags/version