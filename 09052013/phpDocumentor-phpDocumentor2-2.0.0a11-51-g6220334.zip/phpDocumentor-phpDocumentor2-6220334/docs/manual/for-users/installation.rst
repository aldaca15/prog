Installation
============

.. toctree::
   :maxdepth: 2

   installation/using-installer
   installation/using-phar
   installation/using-pear
   installation/upgrading
   installation/troubleshooting

.. toctree::
   :hidden:

   installation/requirements
   installation/ide-integration
