Reporting
=========

.. toctree::
   :maxdepth: 2

   reporting/markers
   reporting/deprecated-elements
   reporting/phpdoc-errors
   reporting/continuous-integration
