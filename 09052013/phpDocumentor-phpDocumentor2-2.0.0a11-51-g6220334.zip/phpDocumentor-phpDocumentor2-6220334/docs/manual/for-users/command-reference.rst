Command reference
=================

.. toctree::
   :maxdepth: 2

   commands/project_run
   commands/project_parse
   commands/project_transform
   commands/template_generate
   commands/template_install
   commands/template_list
   commands/plugin_generate
