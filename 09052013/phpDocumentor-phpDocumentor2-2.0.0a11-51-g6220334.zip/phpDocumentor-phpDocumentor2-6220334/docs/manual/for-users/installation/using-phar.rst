Using PHAR
==========

Requirements
------------

.. include:: requirements.rst

Instructions
------------

You can download the latest PHAR file from
http://www.phpdoc.org/phpDocumentor.phar.

.. important::

   Some installations of PHP can have trouble executing the phar file. If you
   have any issues, please consult the following website first:
   http://silex.sensiolabs.org/doc/phar.html#pitfalls