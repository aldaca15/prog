PHPDoc reference
================

.. toctree::
   :maxdepth: 2

   phpdoc/basic-syntax
   phpdoc/types
   phpdoc/inheritance
   phpdoc/inline-tag-reference
   phpdoc/tag-reference
