system.log.threshold
====================

This event is triggered any time phpDocumentor wants to change which priority of
messages need to logged; it is comparable to the *error_reporting* method of
PHP.

