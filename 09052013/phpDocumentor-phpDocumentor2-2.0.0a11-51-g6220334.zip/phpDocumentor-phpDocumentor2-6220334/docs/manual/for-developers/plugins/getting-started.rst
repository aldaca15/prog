Getting started
===============

.. toctree::
   :maxdepth: 2

   getting-started/what-can-you-do-with-a-plugin
   getting-started/basic-layout
   getting-started/setting-up-a-plugin
