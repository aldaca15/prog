Writing your own plugin
=======================

.. toctree::
   :maxdepth: 2

   plugins/getting-started
   plugins/how-to-add
   plugins/events
