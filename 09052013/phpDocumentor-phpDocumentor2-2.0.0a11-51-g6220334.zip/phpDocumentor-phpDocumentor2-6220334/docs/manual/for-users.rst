For users
=========

.. toctree::
   :maxdepth: 2

   for-users/introduction
   for-users/installation
   for-users/getting-started
   for-users/reporting
   for-users/faq
   for-users/phpdoc-reference
   for-users/configuration
   for-users/command-reference
