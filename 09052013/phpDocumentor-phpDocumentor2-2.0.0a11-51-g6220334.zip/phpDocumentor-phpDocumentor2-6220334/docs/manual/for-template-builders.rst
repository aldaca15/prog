.. phpDocumentor documentation master file, created by
   sphinx-quickstart on Sun Aug 14 09:18:24 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

For template-builders
=====================

.. toctree::
   :maxdepth: 2

   for-template-builders/introduction
   for-template-builders/getting-started
   for-template-builders/configuration
   for-template-builders/writers
