Introduction
============

.. toctree::
   :maxdepth: 2

   introduction/welcome-to-the-template-guide
   introduction/goals
