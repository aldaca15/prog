Getting started
===============

.. toctree::
   :maxdepth: 2

   getting-started/what-can-you-do-with-a-template
   getting-started/basic-layout
   getting-started/quick-start
   getting-started/creating-a-new-template
   getting-started/extending-an-existing-template
