Goals
=====

With this guide we hope that you become just as excited as we are about creating
templates in phpDocumentor2.

After reading this guide you will be familiar with the following:

* How to create a new template
* How to extend a template from another
* How to create a writer for use in your template
* What every configuration setting means

Should you miss some information, do not hesitate to ask on the mailing lists or
submit an issue in our issue tracker. We will try to add the information to the
documentation as soon as possible.