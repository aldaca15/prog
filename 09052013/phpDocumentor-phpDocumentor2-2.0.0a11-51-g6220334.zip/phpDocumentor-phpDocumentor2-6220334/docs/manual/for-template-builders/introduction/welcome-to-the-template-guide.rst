Welcome to the template guide
=============================

Templates are the cornerstones of phpDocumentor2.

They empower you to present information in any format and shape desirable.
May it be a simple HTML layout, an elaborate responsive design, reports in the
format of your choice. Anything is possible.